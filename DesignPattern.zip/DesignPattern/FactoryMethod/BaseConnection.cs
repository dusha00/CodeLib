﻿namespace FactoryMethod
{
   public abstract class BaseConnection
   {
       public abstract void ConnectToDataBase();
   }
}
